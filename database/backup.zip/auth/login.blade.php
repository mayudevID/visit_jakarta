<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Visit Jakarta | Login</title>
        <script src="{{ asset('js/app.js') }}" defer></script>
        @include('partials.header')
    </head>
    <body>
        <header>
            @include('partials.navbar')
        </header>
        <main>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-6"">
                    <h1>HOI</h1>
                    </div>
                    <div class="col">
                    <h1>IOH</h1>
                    </div>
                </div>
            </div>
        </main>
    </body>
</html>